# contest-alert-bot
The discord bot which provides you with alert of coding sites like codeforces, codechef, leetcode etc
following are the command which are currently added to the bot and more are coming - 


IIITA-user {user_name} --user detail

IIITA-contest --contest detail

IIITA-turn_on_auto_contest_alert --24 hour contest alerts

IIITA-add {user_name} --add user to database to get alert message on rating changes

IIITA-remove {username} --remove user from database

IIITA-turn_on_rating_alert will start the rating alert for user names in database
